/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_216()
{
    return 409844141U;
}

unsigned addval_153(unsigned x)
{
    return x + 3351857262U;
}

void setval_157(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_379(unsigned x)
{
    return x + 3347663082U;
}

void setval_329(unsigned *p)
{
    *p = 667127888U;
}

void setval_202(unsigned *p)
{
    *p = 1484138464U;
}

unsigned addval_175(unsigned x)
{
    return x + 3284634056U;
}

unsigned getval_406()
{
    return 3281031256U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_205(unsigned x)
{
    return x + 3526939021U;
}

unsigned addval_382(unsigned x)
{
    return x + 2430634328U;
}

unsigned getval_158()
{
    return 3286272456U;
}

unsigned addval_381(unsigned x)
{
    return x + 3374895497U;
}

unsigned getval_335()
{
    return 3267528993U;
}

unsigned getval_119()
{
    return 3286272328U;
}

void setval_344(unsigned *p)
{
    *p = 3234123401U;
}

void setval_440(unsigned *p)
{
    *p = 3525362313U;
}

unsigned getval_214()
{
    return 3252717896U;
}

unsigned getval_328()
{
    return 1153945993U;
}

unsigned addval_263(unsigned x)
{
    return x + 3677933193U;
}

unsigned getval_262()
{
    return 3234120329U;
}

unsigned getval_318()
{
    return 3677409673U;
}

void setval_457(unsigned *p)
{
    *p = 3374370313U;
}

unsigned getval_378()
{
    return 3252717896U;
}

void setval_459(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_308(unsigned x)
{
    return x + 3281044105U;
}

unsigned addval_413(unsigned x)
{
    return x + 2497743176U;
}

void setval_447(unsigned *p)
{
    *p = 3677933193U;
}

unsigned getval_129()
{
    return 1573110441U;
}

void setval_268(unsigned *p)
{
    *p = 3372273289U;
}

void setval_148(unsigned *p)
{
    *p = 3682914697U;
}

unsigned addval_248(unsigned x)
{
    return x + 3767093852U;
}

void setval_490(unsigned *p)
{
    *p = 2429651318U;
}

unsigned addval_131(unsigned x)
{
    return x + 3525889673U;
}

void setval_291(unsigned *p)
{
    *p = 3529556617U;
}

unsigned getval_250()
{
    return 3531918984U;
}

void setval_468(unsigned *p)
{
    *p = 3334721961U;
}

void setval_322(unsigned *p)
{
    *p = 3223372429U;
}

void setval_288(unsigned *p)
{
    *p = 3465029532U;
}

unsigned getval_224()
{
    return 3348152969U;
}

unsigned getval_123()
{
    return 3223900553U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
